1. Express mongo sanitize demo and implementation
2. Address routes
3. 