Products:
    1. CREATE
    2. READ
    3. UPDATE
    4. DELETE


Payment Integration:
    1. Razorpay

User Management
    1. Signup
    2. Login
    3. Update User Info
    4. Define Roles
    5. Password Reset
    6. Email Verification
    7. User may Add address
    8. Cart
    9. orders


