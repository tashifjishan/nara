#1: No-Sql Injection Prevention
#2: 